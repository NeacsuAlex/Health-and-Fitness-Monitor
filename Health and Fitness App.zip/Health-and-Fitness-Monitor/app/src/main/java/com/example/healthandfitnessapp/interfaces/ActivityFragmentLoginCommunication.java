package com.example.healthandfitnessapp.interfaces;

public interface ActivityFragmentLoginCommunication {

    void openHomeActivity();
    void openLoginFragment();
    void openRegisterFragment();
    void openResetPasswordFragment();
}
